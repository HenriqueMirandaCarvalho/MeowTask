import registerRootComponent from 'expo/build/launch/registerRootComponent';

import App from './src/App.js';

registerRootComponent(App);