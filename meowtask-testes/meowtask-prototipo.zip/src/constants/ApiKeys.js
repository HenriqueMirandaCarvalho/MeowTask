export default {
    FirebaseConfig: {
        apiKey: "AIzaSyBVtoq1D7rsNVPc01ld6LOVZf3bvXoWefQ",
        authDomain: "meowtask-etec.firebaseapp.com",
        databaseURL: "https://meowtask-etec.firebaseio.com",
        projectId: "meowtask-etec",
        storageBucket: "meowtask-etec.appspot.com",
        messagingSenderId: "976694910091",
        appId: "1:976694910091:web:d16f311de423bad725888e",
        measurementId: "G-RRTK0Q1FJ5",
    },
}